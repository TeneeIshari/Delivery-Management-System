package com.example.deliverymanagementsystem.Model;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Entity
@Data
@NoArgsConstructor
public class PostOffice {
    @Id
    private String officeId;
    private String officeName;
    private String district;
    private String province;
    private String contactNo;
    private boolean isActive;

}
