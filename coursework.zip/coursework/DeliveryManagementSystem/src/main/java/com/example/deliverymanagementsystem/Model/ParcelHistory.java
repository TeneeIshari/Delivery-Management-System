package com.example.deliverymanagementsystem.Model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Data
@NoArgsConstructor
public class ParcelHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // auto-increment
    private Long historyId;

    private LocalDateTime updatedTime;

    // Enum for parcel status
    @Enumerated(EnumType.STRING)
    private parcelStatus status;

    private String remarks;

    // Many history records belong to one parcel
    @ManyToOne
    @JoinColumn(name = "parcel_id")
    private Parcel parcel;

    // Each history record can be linked to one post office (optional)
    // Change from LAZY (default) to EAGER
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "post_office_id")
    private PostOffice location;
}
