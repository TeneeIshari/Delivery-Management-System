package com.example.deliverymanagementsystem.Service;

import com.example.deliverymanagementsystem.Model.Parcel;
import com.example.deliverymanagementsystem.Model.ParcelHistory;
import com.example.deliverymanagementsystem.Repository.ParcelHistoryRepo;
import com.example.deliverymanagementsystem.Repository.ParcelRepo;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ParcelService {

    @Autowired
    private ParcelRepo parcelRepo;

    @Autowired
    private ParcelHistoryRepo parcelHistoryRepo;

    // ------------------ PARCEL ------------------

    public List<Parcel> getAllParcels() {
        return parcelRepo.findAll();
    }

    public Parcel saveParcel(Parcel parcel) {
        return parcelRepo.save(parcel);
    }

    public Parcel getParcelById(String id) {
        return parcelRepo.findById(id).orElse(null);
    }

    public void deleteParcel(String id) {
        parcelRepo.deleteById(id);
    }

    public Parcel updateParcel(String id, Parcel updatedParcel) {
        // If parcel exists, update it; otherwise, save as new
        if (parcelRepo.existsById(id)) {
            updatedParcel.setParcelId(id);
        }
        return parcelRepo.save(updatedParcel);
    }

    // ------------------ PARCEL HISTORY ------------------


public List<ParcelHistory> getParcelHistoryByParcelId(String parcelId) {
    System.out.println("Fetching history for parcel: " + parcelId);

    Parcel parcel = getParcelById(parcelId);
    if (parcel == null) {
        System.out.println("Parcel not found!");
        return new ArrayList<>();
    }

    List<ParcelHistory> histories = parcelHistoryRepo.findByParcel_ParcelId(parcelId);
    System.out.println("Found " + histories.size() + " history records");

    // Force load relationships
    histories.forEach(h -> {
        System.out.println("History ID: " + h.getHistoryId() + ", Status: " + h.getStatus());
        if (h.getLocation() != null) {
            System.out.println("Location: " + h.getLocation().getOfficeName());
        }
    });

    return histories;
}



    public ParcelHistory addParcelHistory(String parcelId, ParcelHistory history) {
        Parcel parcel = getParcelById(parcelId);
        if (parcel != null) {
            history.setParcel(parcel);
            ParcelHistory savedHistory = parcelHistoryRepo.save(history);

            // UPDATE THE PARCEL'S STATUS
            parcel.setStatus(history.getStatus());
            parcelRepo.save(parcel);

            return savedHistory;
        }
        return null;
    }

    public void deleteParcelHistory(String parcelId, Long historyId) {
        parcelHistoryRepo.deleteById(historyId);
    }

}
