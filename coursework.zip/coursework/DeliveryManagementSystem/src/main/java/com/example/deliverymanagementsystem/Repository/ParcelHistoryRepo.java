package com.example.deliverymanagementsystem.Repository;

import com.example.deliverymanagementsystem.Model.ParcelHistory;
import com.example.deliverymanagementsystem.Model.PostOffice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ParcelHistoryRepo extends JpaRepository<ParcelHistory, Long> {
    List<ParcelHistory> findByParcel_ParcelId(String parcelId);


}