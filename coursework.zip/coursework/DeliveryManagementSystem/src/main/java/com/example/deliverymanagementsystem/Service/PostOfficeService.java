package com.example.deliverymanagementsystem.Service;

import com.example.deliverymanagementsystem.Model.PostOffice;
import com.example.deliverymanagementsystem.Repository.PostOfficeRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PostOfficeService {

    @Autowired
    private PostOfficeRepo postOfficeRepo;

    public List<PostOffice> getAllOffices() {
        return postOfficeRepo.findAll();
    }

    public PostOffice savePostOffice(PostOffice postOffice) {
        return postOfficeRepo.save(postOffice);
    }

    public PostOffice getPostOfficeById(String id) {
        return postOfficeRepo.findById(id).orElse(null);
    }

    public void deletePostOffice(String id) {
        postOfficeRepo.deleteById(id);
    }

}
