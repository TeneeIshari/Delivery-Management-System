package com.example.deliverymanagementsystem.Repository;
import com.example.deliverymanagementsystem.Model.Parcel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ParcelRepo extends JpaRepository<Parcel, String> {
}
