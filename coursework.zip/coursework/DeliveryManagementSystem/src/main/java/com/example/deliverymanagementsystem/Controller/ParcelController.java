
package com.example.deliverymanagementsystem.Controller;

import com.example.deliverymanagementsystem.Model.Parcel;
import com.example.deliverymanagementsystem.Model.ParcelHistory;
import com.example.deliverymanagementsystem.Model.PostOffice;
import com.example.deliverymanagementsystem.Model.parcelStatus;
import com.example.deliverymanagementsystem.Service.ParcelService;
import com.example.deliverymanagementsystem.Service.PostOfficeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/parcels")
public class ParcelController {

    @Autowired
    private ParcelService parcelService;
    @Autowired
    private PostOfficeService postOfficeService;


    // Get all parcels
    @GetMapping
    public String getAllParcels(Model model) {
        List<Parcel> parcels = parcelService.getAllParcels();
        model.addAttribute("parcels", parcels);
        return "parcels"; //
    }

    // Get a parcel by ID
    @GetMapping("/{id}")
    public String getParcelById(@PathVariable String id, Model model) {
        Parcel parcel = parcelService.getParcelById(id);
        if (parcel == null) {
            return "redirect:/parcels";
        }
        model.addAttribute("parcel", parcel);
        return "edit-parcel";
    }

    // Add parcel
    @GetMapping("/add")
    public String addParcel(Model model) {
        model.addAttribute("parcel", new Parcel());
        model.addAttribute("offices", postOfficeService.getAllOffices());
        return "add-parcel";
    }

    //Edit Parcel By Id
    @GetMapping("/edit/{parcelId}")
    public String showEditForm(@PathVariable String parcelId, Model model) {
        Parcel parcel = parcelService.getParcelById(parcelId);
        if (parcel == null) {
            return "redirect:/parcels";
        }
        model.addAttribute("parcel", parcel);
        model.addAttribute("offices", postOfficeService.getAllOffices());
        return "edit-parcel";
    }

    @PostMapping("/save")
    public String saveParcel(@ModelAttribute("parcel") Parcel parcel,
                             @RequestParam("officeId") String officeId) {

        // Fetch the actual PostOffice object from database
        PostOffice office = postOfficeService.getPostOfficeById(officeId);
        if (office == null) {
            return "redirect:/parcels";
        }

        // Set it to the parcel
        parcel.setAssignedPostOffice(office);

        // Now save
        parcelService.saveParcel(parcel);
        return "redirect:/parcels";
    }


    @PostMapping("/update/{id}")
    public String updateParcel(@PathVariable String id,
                               @ModelAttribute("parcel") Parcel updatedParcel,
                               @RequestParam("officeId") String officeId) {

        // Fetch the PostOffice object
        PostOffice office = postOfficeService.getPostOfficeById(officeId);
        if (office == null) {
            return "redirect:/parcels";
        }
        updatedParcel.setAssignedPostOffice(office);

        parcelService.updateParcel(id, updatedParcel);
        return "redirect:/parcels";
    }

    // 5. Delete a parcel
    @GetMapping("/delete/{id}")
    public String deleteParcel(@PathVariable String id) {
        parcelService.deleteParcel(id);
        return "redirect:/parcels";
    }

    //  PARCEL HISTORY


    @GetMapping("/{id}/history")
    public String getParcelHistory(@PathVariable String id, Model model) {
        try {
            List<ParcelHistory> parcelHistories = parcelService.getParcelHistoryByParcelId(id);

            if (parcelHistories == null) {
                parcelHistories = new ArrayList<>();
            }

            model.addAttribute("parcelHistories", parcelHistories);
            model.addAttribute("parcelId", id);
            model.addAttribute("offices", postOfficeService.getAllOffices());

            return "parcelHistory";
        } catch (Exception e) {
            e.printStackTrace();
            return "redirect:/parcels";
        }
    }

    //  Add a history record for a parcel

    @PostMapping("/{id}/history")
    public String addParcelHistory(@PathVariable String id,
                                   @RequestParam("status") parcelStatus status,  // Changed to enum
                                   @RequestParam("locationId") String locationId,
                                   @RequestParam(value = "remarks", required = false) String remarks) {

        // Create new history object
        ParcelHistory history = new ParcelHistory();
        history.setStatus(status);  // Now it's an enum
        history.setRemarks(remarks);
        history.setUpdatedTime(java.time.LocalDateTime.now());

        // Fetch and set location
        PostOffice location = postOfficeService.getPostOfficeById(locationId);
        history.setLocation(location);

        // Save history
        parcelService.addParcelHistory(id, history);

        return "redirect:/parcels/" + id + "/history";
    }

    //  Delete a specific history record
    @GetMapping("/{parcelId}/history/delete/{historyId}")
    public String deleteParcelHistory(@PathVariable String parcelId, @PathVariable Long historyId) {
        parcelService.deleteParcelHistory(parcelId, historyId);
        return "redirect:/parcels/" + parcelId + "/history";
    }
}