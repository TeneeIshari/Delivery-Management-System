package com.example.deliverymanagementsystem.Controller;

import com.example.deliverymanagementsystem.Model.PostOffice;
import com.example.deliverymanagementsystem.Service.ParcelService;
import com.example.deliverymanagementsystem.Service.PostOfficeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/office")
public class PostOfficeController {

    @Autowired
    private PostOfficeService postOfficeService;

    @Autowired
    private ParcelService parcelService;

    // Show all offices
    @GetMapping
    public String listOffices(Model model) {
        List<PostOffice> postOffices = postOfficeService.getAllOffices();
        model.addAttribute("offices", postOffices);
        return "offices";
    }

    // add form
    @GetMapping("/add")
    public String showAddOfficeForm(Model model) {
        model.addAttribute("postOffice", new PostOffice());
        return "office-add";
    }

    // Save new office
    @PostMapping("/save")
    public String savePostOffice(@ModelAttribute("postOffice") PostOffice postOffice) {
        postOfficeService.savePostOffice(postOffice);
        return "redirect:/office";
    }


    // Show edit form
    @GetMapping("/edit/{officeId}")
    public String showEditForm(@PathVariable String officeId, Model model) {
        PostOffice postOffice = postOfficeService.getPostOfficeById(officeId);
        model.addAttribute("postOffice", postOffice);
        return "edit_office";
    }

    // Update office
    @PostMapping("/update")
    public String updatePostOffice(@ModelAttribute("postOffice") PostOffice postOffice) {
        postOfficeService.savePostOffice(postOffice);
        return "redirect:/office";
    }

//     Delete office
    @GetMapping("/delete/{id}")
    public String deletePostOffice(@PathVariable String id) {
        postOfficeService.deletePostOffice(id);
        return "redirect:/office";
    }

}
