package com.example.deliverymanagementsystem.Model;

public enum parcelStatus {
    REGISTERED,
    AT_ORIGIN_POST_OFFICE,
    IN_TRANSIT,
    AT_DESTINATION_POST_OFFICE,
    OUT_FOR_DELIVERY, DELIVERED,
    DELIVERY_ATTEMPT_FAILED,
    RETURNED_TO_ORIGIN,
    ON_HOLD

}
