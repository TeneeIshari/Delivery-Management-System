package com.example.deliverymanagementsystem.Model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
public class Parcel {
    @Id
    private String parcelId;
    private String senderName;
    private String receiverName;
    private double weight;
    private String category;
    private String currentStatus;
    private LocalDateTime createdDate;

    @Enumerated(EnumType.STRING)
    @Column(name = "status")
    private parcelStatus status;

    // Many parcels can be assigned to one post office
    @ManyToOne
    @JoinColumn(name= "post_office_id")
    private PostOffice assignedPostOffice;

    // One parcel can have many history records
    @OneToMany(mappedBy = "parcel", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ParcelHistory> history;
}
