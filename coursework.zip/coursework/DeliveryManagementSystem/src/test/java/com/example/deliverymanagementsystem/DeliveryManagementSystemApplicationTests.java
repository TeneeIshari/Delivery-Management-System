package com.example.deliverymanagementsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeliveryManagementSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
